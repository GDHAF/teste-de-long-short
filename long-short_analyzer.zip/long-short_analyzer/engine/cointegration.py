"""Fase C: teste Dickey-Fuller sobre o resíduo (Engle-Granger, conforme o manual).

Regressão: Δe_t = α + γ e_{t-1} + u_t ; τ = γ / EP(γ), EP com divisor (n-2).
Valores críticos do manual (Engle-Granger, 2 variáveis, menor amostra):
99% = -4,32 ; 95% = -3,67 ; 90% = -3,28. Teste unilateral à esquerda.

O resultado do teste (τ) é separado da sua interpretação (classify_cointegration_level).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict

from .exceptions import NumericalError
from .regression import linear_regression
from .residuals import lagged_difference, validate_residuals
from .validation import ArrayLike, MIN_OBSERVATIONS, validate_finite

#: Valores críticos do manual (não são os da tabela ADF padrão do statsmodels).
MANUAL_CRITICAL_VALUES: Dict[int, float] = {99: -4.32, 95: -3.67, 90: -3.28}


#: Tolerância numérica (não estatística): SSR/Σ(Δe)² abaixo disso = ajuste perfeito.
_PERFECT_FIT_RTOL = 1e-20


@dataclass(frozen=True)
class DickeyFullerResult:
    tau: float
    gamma: float
    intercept: float
    se_gamma: float
    n_obs: int  # observações da regressão auxiliar (N-1)
    level: int  # 99, 95, 90 ou 0


def classify_cointegration_level(tau: float) -> int:
    """Interpretação do manual. Limites estritos: τ < crítico => nível alcançado."""
    validate_finite(tau, "tau")
    for level in (99, 95, 90):
        if tau < MANUAL_CRITICAL_VALUES[level]:
            return level
    return 0


def dickey_fuller(residuals: ArrayLike, min_obs: int = MIN_OBSERVATIONS) -> DickeyFullerResult:
    s = validate_residuals(residuals, min_obs)
    delta, lag = lagged_difference(s)
    fit = linear_regression(delta, lag)
    ssr = fit.sigma2 * fit.df_resid
    if fit.se_beta <= 0 or ssr <= _PERFECT_FIT_RTOL * float((delta**2).sum()):
        raise NumericalError("Ajuste perfeito na regressão do DF (EP(γ) ~ 0): τ indefinido.")
    tau = validate_finite(fit.beta / fit.se_beta, "tau")
    return DickeyFullerResult(
        tau=tau,
        gamma=fit.beta,
        intercept=fit.alpha,
        se_gamma=fit.se_beta,
        n_obs=fit.n_obs,
        level=classify_cointegration_level(tau),
    )
