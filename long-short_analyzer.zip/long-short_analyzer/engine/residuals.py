"""Resíduos e manipulação de séries estatísticas."""
from __future__ import annotations

from typing import Optional, Tuple

import numpy as np
import pandas as pd

from .exceptions import InvalidSeriesError, NumericalError
from .validation import ArrayLike, MIN_OBSERVATIONS, require_min_samples, to_series


def compute_residuals(
    y: ArrayLike, x: ArrayLike, alpha: float, beta: float, time_coef: Optional[float] = None
) -> pd.Series:
    """e_t = Y_t - (alpha + beta*X_t [+ T*t]) com t = 1..N."""
    ys, xs = to_series(y, "y"), to_series(x, "x")
    if len(ys) != len(xs):
        raise InvalidSeriesError("y e x com tamanhos diferentes.")
    fitted = alpha + beta * xs.to_numpy()
    if time_coef is not None:
        fitted = fitted + time_coef * np.arange(1, len(ys) + 1)
    return pd.Series(ys.to_numpy() - fitted, index=ys.index, name="residual")


def validate_residuals(residuals: ArrayLike, min_obs: int = MIN_OBSERVATIONS) -> pd.Series:
    s = to_series(residuals, "residuals")
    require_min_samples(len(s), min_obs, "série de resíduos")
    return s


def residual_mean_std(residuals: ArrayLike, ddof: int = 1) -> Tuple[float, float]:
    s = to_series(residuals, "residuals")
    if len(s) - ddof < 1:
        raise NumericalError("Amostra insuficiente para o desvio padrão.")
    return float(s.mean()), float(s.std(ddof=ddof))


def standardize(residuals: ArrayLike, ddof: int = 1) -> pd.Series:
    """Série z_t = (e_t - média)/desvio, para todo t."""
    s = to_series(residuals, "residuals")
    mean, std = residual_mean_std(s, ddof)
    if std <= 0 or not np.isfinite(std):
        raise NumericalError("Desvio padrão do resíduo nulo ou inválido.")
    return (s - mean) / std


def lagged_difference(residuals: ArrayLike) -> Tuple[pd.Series, pd.Series]:
    """Retorna (Δe_t, e_{t-1}) para t = 2..N — base do DF e da meia-vida."""
    s = to_series(residuals, "residuals")
    lag = s.iloc[:-1]
    delta = pd.Series(s.to_numpy()[1:] - s.to_numpy()[:-1], index=s.index[1:], name="delta")
    lag = pd.Series(lag.to_numpy(), index=s.index[1:], name="lag")
    return delta, lag
