"""Exceções de domínio do motor estatístico."""


class EngineError(Exception):
    """Base de todos os erros do motor."""


class InvalidSeriesError(EngineError):
    """Série inválida: vazia, não numérica, com NaN/inf, índice duplicado, preço <= 0."""


class MisalignedSeriesError(EngineError):
    """Séries sem datas em comum ou com comprimentos/índices incompatíveis."""


class InsufficientSampleError(EngineError):
    """Amostra menor que o mínimo exigido pela operação."""


class SingularRegressionError(EngineError):
    """Matriz de regressão singular (regressor constante ou colinear)."""


class NonMeanRevertingError(EngineError):
    """Série sem reversão à média: não é possível estimar meia-vida."""


class NumericalError(EngineError):
    """Resultado numérico inválido (NaN, inf, divisão por zero, variância nula)."""
