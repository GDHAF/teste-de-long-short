"""Fase B: regressão OLS (A = alpha + beta*B [+ T*t] + resíduo).

Convenção do manual: A (y) dependente, B (x) independente, t = 1..N.
Álgebra matricial: beta_hat = (X'X)^-1 X'y ; Cov = s^2 (X'X)^-1, s^2 = SSR/(n-p).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Union

import numpy as np
import pandas as pd

from .exceptions import InsufficientSampleError, InvalidSeriesError, MisalignedSeriesError, SingularRegressionError
from .validation import ArrayLike, to_series, validate_finite

Residuals = Union[pd.Series, np.ndarray]


@dataclass(frozen=True)
class RegressionResult:
    """Contrato de retorno de linear_regression. Ordem de params: [alpha, beta, (T)]."""

    alpha: float
    beta: float
    time_coef: Optional[float]
    se_alpha: float
    se_beta: float
    se_time: Optional[float]
    covariance: np.ndarray
    fitted: pd.Series
    residuals: pd.Series
    n_obs: int
    n_params: int
    df_resid: int
    sigma2: float
    with_time: bool


def linear_regression(y: ArrayLike, x: ArrayLike, with_time: bool = False) -> RegressionResult:
    """OLS de y sobre x (com intercepto) e, opcionalmente, sobre o tempo t=1..N."""
    ys, xs = to_series(y, "y"), to_series(x, "x")
    if len(ys) != len(xs):
        raise MisalignedSeriesError(f"y e x com tamanhos diferentes ({len(ys)} vs {len(xs)}).")
    if isinstance(y, pd.Series) and isinstance(x, pd.Series) and not ys.index.equals(xs.index):
        raise MisalignedSeriesError("y e x possuem índices diferentes; alinhe antes (align_prices).")

    n = len(ys)
    p = 3 if with_time else 2
    if n - p < 1:
        raise InsufficientSampleError(f"Regressão com {p} parâmetros exige ao menos {p + 1} observações (n={n}).")

    yv, xv = ys.to_numpy(), xs.to_numpy()
    cols = [np.ones(n), xv] + ([np.arange(1, n + 1, dtype="float64")] if with_time else [])
    design = np.column_stack(cols)
    if np.linalg.matrix_rank(design) < p:
        raise SingularRegressionError("Regressor constante ou colinear: matriz X'X singular.")

    coef, *_ = np.linalg.lstsq(design, yv, rcond=None)
    fitted = design @ coef
    resid = yv - fitted
    df_resid = n - p
    sigma2 = float(resid @ resid) / df_resid
    cov = sigma2 * np.linalg.inv(design.T @ design)
    se = np.sqrt(np.diag(cov))

    for label, val in zip(("alpha", "beta", "time_coef"), coef):
        validate_finite(val, label)
    return RegressionResult(
        alpha=float(coef[0]),
        beta=float(coef[1]),
        time_coef=float(coef[2]) if with_time else None,
        se_alpha=float(se[0]),
        se_beta=float(se[1]),
        se_time=float(se[2]) if with_time else None,
        covariance=cov,
        fitted=pd.Series(fitted, index=ys.index, name="fitted"),
        residuals=pd.Series(resid, index=ys.index, name="residual"),
        n_obs=n,
        n_params=p,
        df_resid=df_resid,
        sigma2=sigma2,
        with_time=with_time,
    )
