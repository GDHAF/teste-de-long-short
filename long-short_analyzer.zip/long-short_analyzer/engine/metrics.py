"""Fase D: métricas estatísticas (z-score, meia-vida, Fisher, IC e testes t)."""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Literal, Optional, Tuple

import numpy as np
from scipy import stats

from .exceptions import InvalidSeriesError, NonMeanRevertingError, NumericalError
from .regression import linear_regression
from .residuals import lagged_difference, residual_mean_std, validate_residuals
from .validation import ArrayLike, MIN_OBSERVATIONS, to_series, validate_finite


#: Tolerância numérica (não estatística) para rejeitar θ indistinguível de zero.
_THETA_MIN = 1e-10


def z_score(residuals: ArrayLike, ddof: int = 1, min_obs: int = MIN_OBSERVATIONS) -> float:
    """z = (e_N - média)/σ_e sobre o último ponto. ddof=1 (amostral) é decisão a confirmar."""
    s = validate_residuals(residuals, min_obs)
    mean, std = residual_mean_std(s, ddof)
    if std <= 0:
        raise NumericalError("Desvio padrão do resíduo nulo: z-score indefinido.")
    return validate_finite((float(s.iloc[-1]) - mean) / std, "z_score")


def half_life(residuals: ArrayLike, min_obs: int = MIN_OBSERVATIONS) -> float:
    """HL = ln(2)/θ, com θ = -γ da regressão Δe_t = α + γ e_{t-1} + u (Ornstein-Uhlenbeck discreto).

    Rejeita (NonMeanRevertingError) γ >= 0 (sem reversão) ou θ não finito.
    """
    s = validate_residuals(residuals, min_obs)
    delta, lag = lagged_difference(s)
    gamma = linear_regression(delta, lag).beta
    theta = -gamma
    if not math.isfinite(theta) or theta <= _THETA_MIN:
        raise NonMeanRevertingError(f"Sem reversão à média (γ={gamma:.6g} >= 0); meia-vida indefinida.")
    return validate_finite(math.log(2) / theta, "half_life")


def pearson_correlation(a: ArrayLike, b: ArrayLike) -> float:
    sa, sb = to_series(a, "a"), to_series(b, "b")
    if len(sa) != len(sb) or len(sa) < 3:
        raise InvalidSeriesError("Correlação exige séries de mesmo tamanho (>= 3).")
    if sa.std() == 0 or sb.std() == 0:
        raise NumericalError("Série constante: correlação indefinida.")
    return validate_finite(float(np.corrcoef(sa.to_numpy(), sb.to_numpy())[0, 1]), "correlation")


def fisher_test(
    corr: float, n: int, conf: float = 0.99, z_critical: Optional[float] = None
) -> Tuple[float, float]:
    """IC de ρ pela transformada de Fisher: tanh(atanh(ρ) ± z/√(n-3)).

    z_critical permite usar o valor tabelado do manual (1,96 / 2,575); por padrão,
    z = Φ^-1(1-(1-conf)/2).
    """
    if not (-1 < corr < 1) or not math.isfinite(corr):
        raise NumericalError("Correlação deve estar em (-1, 1) para a transformada de Fisher.")
    if n <= 3:
        raise NumericalError("Fisher exige n > 3.")
    if not (0 < conf < 1):
        raise ValueError("conf deve estar em (0, 1).")
    z = z_critical if z_critical is not None else float(stats.norm.ppf(1 - (1 - conf) / 2))
    f = math.atanh(corr)
    half = z / math.sqrt(n - 3)
    return math.tanh(f - half), math.tanh(f + half)


def beta_confidence_interval(beta: float, se: float, n: int, k: int, conf: float = 0.95) -> Tuple[float, float]:
    """IC bilateral t-Student com gl = n-k-1 (k = nº de regressores além do intercepto)."""
    df = n - k - 1
    if df < 1 or se < 0 or not math.isfinite(se):
        raise NumericalError("Parâmetros inválidos para o IC (gl < 1 ou erro padrão inválido).")
    t_crit = float(stats.t.ppf(1 - (1 - conf) / 2, df))
    return beta - t_crit * se, beta + t_crit * se


@dataclass(frozen=True)
class TTestResult:
    t_stat: float
    df: int
    p_value: float


def coefficient_t_test(
    coef: float, se: float, n: int, k: int, tail: Literal["two", "right", "left"] = "two"
) -> TTestResult:
    """Teste t para H0: coef = 0, gl = n-k-1."""
    df = n - k - 1
    if df < 1:
        raise NumericalError("Graus de liberdade insuficientes.")
    if not math.isfinite(se) or se <= 0:
        raise NumericalError("Erro padrão nulo ou inválido: estatística t indefinida.")
    t_stat = validate_finite(coef / se, "t_stat")
    if tail == "two":
        p = 2 * float(stats.t.sf(abs(t_stat), df))
    elif tail == "right":
        p = float(stats.t.sf(t_stat, df))
    elif tail == "left":
        p = float(stats.t.cdf(t_stat, df))
    else:
        raise ValueError("tail deve ser 'two', 'right' ou 'left'.")
    return TTestResult(t_stat=t_stat, df=df, p_value=p)
