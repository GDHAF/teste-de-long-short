import math

import numpy as np
import pytest

from engine.exceptions import (InsufficientDataError, InvalidSeriesError,
                               NonFiniteResultError, NonMeanRevertingError)
from engine.metrics import half_life, residual_std, z_score, z_score_series
from .helpers import ar1


def test_z_score_hand_computed():
    e = [1, 2, 3, 4, 10]  # média 4; var amostral 12,5; var populacional 10
    assert z_score(e) == pytest.approx(6 / math.sqrt(12.5), rel=1e-12)
    assert z_score(e, ddof=0) == pytest.approx(6 / math.sqrt(10.0), rel=1e-12)
    assert residual_std(e) == pytest.approx(math.sqrt(12.5), rel=1e-12)


def test_z_score_series_properties():
    z = z_score_series(ar1(200, 0.6, 1))
    assert abs(z.mean()) < 1e-12 and np.std(z, ddof=1) == pytest.approx(1.0, rel=1e-12)
    assert z_score(ar1(200, 0.6, 1)) == z[-1]


def test_z_score_sign():
    e = np.array([0.0, 1, -1, 0.5, -0.5, 0, 2.0])
    assert z_score(e) > 0
    assert z_score(np.append(e[:-1], -2.0)) < 0


def test_z_score_invalid():
    with pytest.raises(NonFiniteResultError):
        z_score(np.full(10, 2.0))
    with pytest.raises(InsufficientDataError):
        z_score([1.0])
    with pytest.raises(InvalidSeriesError):
        z_score([1.0, np.nan, 3.0])
    with pytest.raises(InvalidSeriesError):
        z_score([])


def test_half_life_exact_deterministic_decay():
    for phi in (0.5, 0.9, 0.95):
        e = phi ** np.arange(60)  # Δe = (φ-1)e_{t-1} exatamente
        expected = math.log(2) / (1 - phi)
        assert abs(half_life(e) - expected) / expected < 1e-6


def test_half_life_ar1_statistical():
    e = ar1(20000, 0.9, seed=5)
    expected = math.log(2) / 0.1
    assert abs(half_life(e) - expected) / expected < 0.1


def test_half_life_faster_for_smaller_phi():
    assert half_life(ar1(5000, 0.5, 3)) < half_life(ar1(5000, 0.95, 3))


def test_half_life_rejects_non_mean_reverting():
    trend = np.arange(100.0) ** 1.5  # explosivo/crescente: γ>0
    with pytest.raises(NonMeanRevertingError):
        half_life(trend)
    explosive = 1.1 ** np.arange(40)
    with pytest.raises(NonMeanRevertingError):
        half_life(explosive)


def test_half_life_rejects_oscillatory():
    e = (-0.5) ** np.arange(40) 
    with pytest.raises(NonMeanRevertingError):
        half_life(e)


def test_half_life_invalid_inputs():
    with pytest.raises(InvalidSeriesError):
        half_life([1, 2, np.inf, 4, 5])
    with pytest.raises(InsufficientDataError):
        half_life([1.0, 2.0])
