import numpy as np
import pandas as pd
import pytest

from engine.exceptions import (InsufficientDataError, MisalignedSeriesError)
from engine.pair_analysis import CONTRACT_KEYS_PENDING, pair_stats
from engine.regression import linear_regression
from .helpers import cointegrated_pair, dates, independent_walks

IMPLEMENTED = {"beta", "alpha", "residuals", "dickey_fuller", "cointegration_level",
               "z_score_current", "half_life", "std_residual", "t_beta", "t_alpha"}


def test_cointegrated_pair_contract():
    a, b = cointegrated_pair(n=300)
    out = pair_stats(a, b, 250)
    assert set(out) == IMPLEMENTED
    assert not set(CONTRACT_KEYS_PENDING) & set(out)  # sem placeholders
    assert out["beta"] == pytest.approx(0.8, abs=0.1)
    assert out["cointegration_level"] >= 95
    assert out["half_life"] is not None and out["half_life"] < 10
    assert len(out["residuals"]) == 250 and out["residuals"].index.equals(a.index[-250:])
    assert out["std_residual"] > 0 and abs(out["z_score_current"]) < 6
    assert out["t_beta"] > 2.39


def test_matches_direct_regression_on_last_window():
    a, b = cointegrated_pair(n=300, seed=3)
    out = pair_stats(a, b, 120)
    ref = linear_regression(a.iloc[-120:].to_numpy(), b.iloc[-120:].to_numpy())
    assert out["beta"] == pytest.approx(ref.beta, rel=1e-12)
    assert out["alpha"] == pytest.approx(ref.alpha, rel=1e-12)
    assert out["t_beta"] == pytest.approx(ref.t_beta, rel=1e-12)


def test_with_time_adds_t_time():
    a, b = cointegrated_pair(n=200)
    out = pair_stats(a, b, 150, with_time=True)
    assert "t_time" in out and np.isfinite(out["t_time"])
    assert "t_time" not in pair_stats(a, b, 150)


def test_non_cointegrated_pair():
    a, b = independent_walks()
    out = pair_stats(a, b, 250)
    assert out["cointegration_level"] == 0


def test_misaligned_and_missing_observations():
    a, b = cointegrated_pair(n=300)
    a2 = a.copy(); a2.iloc[[10, 50, 100]] = np.nan
    b2 = b.drop(b.index[[20, 60]])
    out = pair_stats(a2, b2, 250)
    assert len(out["residuals"]) == 250
    dropped = a.index[[10, 50, 100, 20, 60]]
    assert not out["residuals"].index.isin(dropped).any()
    with pytest.raises(MisalignedSeriesError):
        pair_stats(a, pd.Series(b.to_numpy(), dates(300, "2000-01-03")), 100)


def test_insufficient_sample():
    a, b = cointegrated_pair(n=100)
    with pytest.raises(InsufficientDataError):
        pair_stats(a, b, 250)
    with pytest.raises(InsufficientDataError):
        pair_stats(a.iloc[:30], b.iloc[:30], 30)  # abaixo do piso técnico


def test_invalid_n_periods():
    a, b = cointegrated_pair(n=100)
    for bad in (0, -5, 10.5, True):
        with pytest.raises(ValueError):
            pair_stats(a, b, bad)


def test_deterministic():
    a, b = cointegrated_pair(n=250)
    o1, o2 = pair_stats(a, b, 200), pair_stats(a, b, 200)
    assert o1["dickey_fuller"] == o2["dickey_fuller"]
    assert o1["residuals"].equals(o2["residuals"])
