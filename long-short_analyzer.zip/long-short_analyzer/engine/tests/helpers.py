import numpy as np
import pandas as pd


def dates(n, start="2024-01-01"):
    return pd.bdate_range(start, periods=n)


def ar1(n, phi, seed, sigma=1.0):
    rng = np.random.default_rng(seed)
    e = np.zeros(n)
    eps = rng.normal(0, sigma, n)
    for t in range(1, n):
        e[t] = phi * e[t - 1] + eps[t]
    return e


def cointegrated_pair(n=250, beta=0.8, alpha=5.0, phi=0.5, seed=1):
    rng = np.random.default_rng(seed)
    x = 50 + np.cumsum(rng.normal(0, 1, n))
    y = alpha + beta * x + ar1(n, phi, seed + 100)
    idx = dates(n)
    return pd.Series(y, idx), pd.Series(x, idx)


def independent_walks(n=250, seed=7):
    rng = np.random.default_rng(seed)
    idx = dates(n)
    return (pd.Series(100 + np.cumsum(rng.normal(0, 1, n)), idx),
            pd.Series(100 + np.cumsum(rng.normal(0, 1, n)), idx))
