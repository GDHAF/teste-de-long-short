import numpy as np
import pandas as pd
import pytest

from engine.exceptions import (InsufficientDataError, InvalidSeriesError,
                               MisalignedSeriesError, NonFiniteResultError)
from engine.validation import (align_price_series, as_float_array, ensure_finite,
                               require_min_observations)
from .helpers import dates


@pytest.mark.parametrize("bad", [None, "abc", [], [1.0, np.nan], [1.0, np.inf], [[1, 2], [3, 4]], ["a", "b"]])
def test_as_float_array_rejects_invalid(bad):
    with pytest.raises(InvalidSeriesError):
        as_float_array(bad)


def test_as_float_array_accepts_list_and_series():
    assert as_float_array([1, 2, 3]).dtype == float
    assert as_float_array(pd.Series([1.0, 2.0])).tolist() == [1.0, 2.0]


def test_require_min_observations():
    require_min_observations(5, 5)
    with pytest.raises(InsufficientDataError):
        require_min_observations(4, 5)


def test_ensure_finite():
    assert ensure_finite(1.5, "v") == 1.5
    for bad in (float("nan"), float("inf"), "x"):
        with pytest.raises(NonFiniteResultError):
            ensure_finite(bad, "v")


def test_align_misaligned_dates_uses_intersection():
    a = pd.Series(np.arange(1, 11.0), dates(10))
    # b tem 7 datas em comum com a (índices 3..9) + 3 datas fora
    b = pd.Series(np.arange(1, 11.0), pd.DatetimeIndex(list(dates(10)[3:]) + list(pd.bdate_range("2023-01-02", periods=3))))
    ra, rb = align_price_series(a, b)
    assert list(ra.index) == list(dates(10)[3:])
    assert ra.index.equals(rb.index)


def test_align_no_overlap():
    a = pd.Series([1.0, 2.0], dates(2, "2024-01-01"))
    b = pd.Series([1.0, 2.0], dates(2, "2020-01-01"))
    with pytest.raises(MisalignedSeriesError):
        align_price_series(a, b)


def test_align_drops_missing_and_invalid_rowwise():
    idx = dates(6)
    a = pd.Series([1.0, np.nan, 3.0, 4.0, -5.0, 6.0], idx)
    b = pd.Series([1.0, 2.0, np.inf, 4.0, 5.0, 6.0], idx)
    ra, rb = align_price_series(a, b)
    assert list(ra.index) == [idx[0], idx[3], idx[5]]
    assert rb.tolist() == [1.0, 4.0, 6.0]


def test_align_sorts_unsorted_index():
    idx = dates(4)
    a = pd.Series([4.0, 3.0, 2.0, 1.0], idx[::-1])
    b = pd.Series([1.0, 2.0, 3.0, 4.0], idx)
    ra, _ = align_price_series(a, b)
    assert ra.index.is_monotonic_increasing


def test_align_rejects_duplicates_and_non_series():
    idx = pd.DatetimeIndex(["2024-01-01", "2024-01-01"])
    with pytest.raises(InvalidSeriesError):
        align_price_series(pd.Series([1.0, 2.0], idx), pd.Series([1.0, 2.0], idx))
    with pytest.raises(InvalidSeriesError):
        align_price_series([1, 2], pd.Series([1.0, 2.0]))


def test_align_all_invalid():
    idx = dates(3)
    with pytest.raises(InsufficientDataError):
        align_price_series(pd.Series([np.nan] * 3, idx), pd.Series([1.0, 2.0, 3.0], idx))
