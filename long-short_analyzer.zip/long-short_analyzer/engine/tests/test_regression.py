import numpy as np
import pytest
import statsmodels.api as sm

from engine.exceptions import (InsufficientDataError, InvalidSeriesError,
                               SingularRegressionError)
from engine.regression import linear_regression
from engine.residuals import compute_residuals


def rel(a, b):
    return abs(a - b) / abs(b)


def test_exact_simple_regression_recovers_parameters():
    x = np.linspace(10, 50, 30)
    y = 2.0 + 0.5 * x
    r = linear_regression(y, x)
    assert rel(r.alpha, 2.0) < 1e-10 and rel(r.beta, 0.5) < 1e-10
    assert r.time_coef is None and r.t_time is None and r.se_time is None
    assert np.allclose(r.residuals, 0, atol=1e-10)


def test_noisy_regression_matches_normal_equations_and_statsmodels():
    rng = np.random.default_rng(3)
    x = 40 + np.cumsum(rng.normal(size=120))
    y = 3 + 0.7 * x + rng.normal(size=120)
    r = linear_regression(y, x)
    X = np.column_stack([np.ones_like(x), x])
    beta_hat = np.linalg.solve(X.T @ X, X.T @ y)          # β̂ = (X'X)^-1 X'Y
    assert np.allclose(r.coefficients, beta_hat, rtol=1e-9)
    m = sm.OLS(y, X).fit()
    for got, ref in [(r.coefficients, m.params), (r.std_errors, m.bse),
                     (r.t_values, m.tvalues), (r.covariance, m.cov_params()),
                     (r.fitted, m.fittedvalues), (r.residuals, m.resid)]:
        assert np.allclose(got, ref, rtol=1e-8, atol=1e-10)
    assert r.df_resid == 118 and r.n_params == 2 and r.n_obs == 120


def test_regression_with_time_exact():
    n = 60
    x = 20 + np.sin(np.arange(n) / 3.0) * 5
    t = np.arange(1, n + 1)
    y = 1.0 + 2.0 * x + 0.3 * t
    r = linear_regression(y, x, with_time=True)
    assert rel(r.alpha, 1.0) < 1e-8 and rel(r.beta, 2.0) < 1e-8 and rel(r.time_coef, 0.3) < 1e-8


def test_regression_with_time_matches_statsmodels():
    rng = np.random.default_rng(11)
    n = 150
    x = 30 + np.cumsum(rng.normal(size=n))
    y = 5 + 0.4 * x + 0.05 * np.arange(1, n + 1) + rng.normal(size=n)
    r = linear_regression(y, x, with_time=True)
    X = np.column_stack([np.ones(n), x, np.arange(1, n + 1)])
    m = sm.OLS(y, X).fit()
    assert np.allclose(r.coefficients, m.params, rtol=1e-8)
    assert np.allclose(r.std_errors, m.bse, rtol=1e-8)
    assert r.t_time == pytest.approx(m.tvalues[2], rel=1e-8)
    assert r.se_time == pytest.approx(m.bse[2], rel=1e-8)
    assert r.n_params == 3 and r.df_resid == n - 3


def test_residuals_definition():
    rng = np.random.default_rng(5)
    x = rng.uniform(10, 20, 50)
    y = 1 + 2 * x + rng.normal(size=50)
    r = linear_regression(y, x)
    assert np.allclose(compute_residuals(y, x, r.alpha, r.beta), r.residuals)
    rt = linear_regression(y, x, with_time=True)
    assert np.allclose(compute_residuals(y, x, rt.alpha, rt.beta, rt.time_coef), rt.residuals)
    assert abs(r.residuals.mean()) < 1e-10  # com intercepto, média zero
    assert abs(r.residuals @ x) < 1e-8      # ortogonal ao regressor


def test_invalid_inputs():
    with pytest.raises(InvalidSeriesError):
        linear_regression([1, 2, 3], [1, 2])
    with pytest.raises(InvalidSeriesError):
        linear_regression([1, np.nan, 3, 4], [1, 2, 3, 4])
    with pytest.raises(InvalidSeriesError):
        linear_regression([1, 2, np.inf, 4], [1, 2, 3, 4])
    with pytest.raises(InsufficientDataError):
        linear_regression([1, 2], [1, 2])
    with pytest.raises(InsufficientDataError):
        linear_regression([1, 2, 3], [1, 2, 4], with_time=True)


def test_singular_cases():
    with pytest.raises(SingularRegressionError):
        linear_regression([1.0, 2.0, 3.0, 4.0], [5.0, 5.0, 5.0, 5.0])
    t = np.arange(1, 11.0)
    with pytest.raises(SingularRegressionError):  # x colinear com t
        linear_regression(np.random.default_rng(0).normal(size=10), 2 * t + 1, with_time=True)


def test_constant_y_is_valid_with_zero_beta():
    x = np.arange(1.0, 11.0)
    r = linear_regression(np.full(10, 4.0), x)
    assert r.beta == pytest.approx(0, abs=1e-12) and r.alpha == pytest.approx(4.0)


def test_large_price_scale_precision():
    x = 1e6 + np.arange(100.0)
    y = 7.0 + 1.5 * x
    r = linear_regression(y, x)
    assert rel(r.beta, 1.5) < 1e-8
