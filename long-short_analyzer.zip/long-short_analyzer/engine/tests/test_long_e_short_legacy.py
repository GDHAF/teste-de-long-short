from long_e_short import LongEShort


def test_legacy_behavior_unchanged():
    s = LongEShort()
    assert s.calcular(100, 48, 1, -2, 1) == {"A": -1, "B": 2}   # spread = 4 > tol
    assert s.calcular(100, 50, 1, -2, 1) == {"A": 0, "B": 0}    # spread = 0
    assert s.calcular(90, 50, 1, -2, 1) == {"A": 1, "B": -2}    # spread = -10
