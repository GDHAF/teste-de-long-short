import numpy as np
import pytest
import statsmodels.api as sm
from statsmodels.tsa.stattools import adfuller

from engine.cointegration import (CRITICAL_VALUES, classify_cointegration_level,
                                  dickey_fuller)
from engine.exceptions import (InsufficientDataError, InvalidSeriesError,
                               NonFiniteResultError, SingularRegressionError)
from engine.regression import linear_regression
from .helpers import ar1, cointegrated_pair, independent_walks


def test_manual_example_gamma_over_se():
    # Manual p.42: γ=-0,190; EP=0,048 -> τ=-3,958 -> 95%
    tau = -0.190 / 0.048
    assert abs(tau - (-3.958)) / 3.958 < 1e-3  # manual arredonda a 3 casas
    assert classify_cointegration_level(-3.958) == 95


@pytest.mark.parametrize("tau,level", [(-4.50, 99), (-4.33, 99), (-4.32, 95), (-4.0, 95),
                                       (-3.67, 90), (-3.50, 90), (-3.28, 0), (-3.0, 0), (2.0, 0)])
def test_classification_thresholds(tau, level):
    assert classify_cointegration_level(tau) == level


def test_critical_values_are_manual_values():
    assert CRITICAL_VALUES == {99: -4.32, 95: -3.67, 90: -3.28}


def test_classification_rejects_nan():
    with pytest.raises(NonFiniteResultError):
        classify_cointegration_level(float("nan"))


def test_tau_matches_independent_ols_and_adfuller_statistic():
    e = ar1(250, 0.7, seed=21)
    res = dickey_fuller(e)
    de, lag = np.diff(e), e[:-1]
    m = sm.OLS(de, sm.add_constant(lag)).fit()
    assert abs(res.tau - m.tvalues[1]) / abs(m.tvalues[1]) < 1e-9
    assert abs(res.gamma - m.params[1]) / abs(m.params[1]) < 1e-9
    # mesma estatística t do ADF com constante e 0 defasagens (apenas a estatística)
    adf_stat = adfuller(e, maxlag=0, regression="c", autolag=None, result_object=False)[0]
    assert abs(res.tau - adf_stat) / abs(adf_stat) < 1e-9
    assert res.n_obs == 249


def test_se_formula_from_manual():
    e = ar1(120, 0.6, seed=4)
    res = dickey_fuller(e)
    reg = linear_regression(np.diff(e), e[:-1])
    n = len(e) - 1
    se_manual = np.sqrt((reg.residuals ** 2).sum() / (n - 2)) / np.sqrt(((e[:-1] - e[:-1].mean()) ** 2).sum())
    assert abs(res.std_error - se_manual) / se_manual < 1e-10


def test_stationary_residual_is_cointegrated_at_99():
    res = dickey_fuller(ar1(250, 0.5, seed=2))
    assert res.tau < -4.32 and res.cointegration_level == 99


def test_cointegrated_pair_residual():
    y, x = cointegrated_pair()
    r = linear_regression(y.to_numpy(), x.to_numpy())
    assert dickey_fuller(r.residuals).cointegration_level >= 95


def test_random_walk_residual_not_cointegrated():
    y, x = independent_walks()
    r = linear_regression(y.to_numpy(), x.to_numpy())
    assert dickey_fuller(r.residuals).cointegration_level == 0


def test_unit_root_series_level_zero():
    e = np.cumsum(np.random.default_rng(9).normal(size=300))
    assert dickey_fuller(e).cointegration_level == 0


def test_invalid_and_insufficient():
    with pytest.raises(InvalidSeriesError):
        dickey_fuller([1, 2, np.nan, 4, 5])
    with pytest.raises(InvalidSeriesError):
        dickey_fuller([])
    with pytest.raises(InsufficientDataError):
        dickey_fuller([1.0, 2.0, 3.0])
    with pytest.raises(SingularRegressionError):
        dickey_fuller(np.full(20, 3.0))


def test_perfect_fit_raises():
    with pytest.raises(NonFiniteResultError):
        dickey_fuller(0.9 ** np.arange(30))
