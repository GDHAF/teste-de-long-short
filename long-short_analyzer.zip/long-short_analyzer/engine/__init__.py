"""Motor estatístico Long & Short por cointegração (Engle-Granger). Independente de Django."""
from .cointegration import MANUAL_CRITICAL_VALUES, DickeyFullerResult, classify_cointegration_level, dickey_fuller
from .exceptions import (
    EngineError, InsufficientSampleError, InvalidSeriesError, MisalignedSeriesError,
    NonMeanRevertingError, NumericalError, SingularRegressionError,
)
from .metrics import (
    beta_confidence_interval, coefficient_t_test, fisher_test, half_life, pearson_correlation, z_score,
)
from .pair_analysis import CONTRACT_KEYS, pair_stats
from .regression import RegressionResult, linear_regression
from .residuals import compute_residuals, standardize

__all__ = [n for n in dir() if not n.startswith("_")]
