"""Fase A: validação de entradas, alinhamento temporal e validação de saídas."""
from __future__ import annotations

import math
from typing import Literal, Sequence, Union

import numpy as np
import pandas as pd

from .exceptions import (
    InsufficientSampleError,
    InvalidSeriesError,
    MisalignedSeriesError,
    NumericalError,
)

#: Mínimo de observações para estatísticas inferenciais (DF, meia-vida, pair_stats).
#: Escolha de engenharia (o manual exige beta rotation >= 40; janelas padrão >= 70).
MIN_OBSERVATIONS = 30

ArrayLike = Union[pd.Series, np.ndarray, Sequence[float]]


def to_series(values: ArrayLike, name: str = "series", *, allow_nan: bool = False) -> pd.Series:
    """Converte para pd.Series float64 validada (índice único e crescente)."""
    if isinstance(values, pd.DataFrame):
        raise InvalidSeriesError(f"'{name}' deve ser unidimensional, recebeu DataFrame.")
    try:
        s = values.copy() if isinstance(values, pd.Series) else pd.Series(np.asarray(values))
        s = s.astype("float64")
    except (TypeError, ValueError) as exc:
        raise InvalidSeriesError(f"'{name}' contém valores não numéricos.") from exc
    if s.ndim != 1 or s.empty:
        raise InvalidSeriesError(f"'{name}' está vazia ou não é unidimensional.")
    if np.isinf(s.to_numpy()).any():
        raise InvalidSeriesError(f"'{name}' contém valores infinitos.")
    if not allow_nan and s.isna().any():
        raise InvalidSeriesError(f"'{name}' contém {int(s.isna().sum())} valor(es) ausente(s).")
    if s.index.has_duplicates:
        raise InvalidSeriesError(f"'{name}' possui datas/índices duplicados.")
    if not s.index.is_monotonic_increasing:
        s = s.sort_index()
    return s


def validate_prices(values: ArrayLike, name: str = "prices", *, allow_nan: bool = False) -> pd.Series:
    """Série de preços: numérica, finita e estritamente positiva."""
    s = to_series(values, name, allow_nan=allow_nan)
    if (s.dropna() <= 0).any():
        raise InvalidSeriesError(f"'{name}' contém preços não positivos.")
    return s


def align_prices(
    prices_a: ArrayLike,
    prices_b: ArrayLike,
    *,
    missing: Literal["raise", "drop"] = "raise",
) -> pd.DataFrame:
    """Alinha A e B pela interseção de índices (colunas 'A' e 'B').

    missing="raise": qualquer NaN na interseção é erro.
    missing="drop":  remove linhas com NaN em qualquer ativo (conjuntamente).
    """
    if missing not in ("raise", "drop"):
        raise ValueError("missing deve ser 'raise' ou 'drop'.")
    a = validate_prices(prices_a, "prices_a", allow_nan=True)
    b = validate_prices(prices_b, "prices_b", allow_nan=True)
    df = pd.concat([a.rename("A"), b.rename("B")], axis=1, join="inner")
    if df.empty:
        raise MisalignedSeriesError("As séries não possuem datas/índices em comum.")
    if df.isna().any().any():
        if missing == "raise":
            raise InvalidSeriesError(
                f"{int(df.isna().any(axis=1).sum())} observação(ões) ausente(s) no período alinhado."
            )
        df = df.dropna()
        if df.empty:
            raise InsufficientSampleError("Nenhuma observação válida após remover ausentes.")
    return df


def require_min_samples(n: int, minimum: int, what: str = "operação") -> None:
    if n < minimum:
        raise InsufficientSampleError(f"{what}: {n} observações, mínimo exigido {minimum}.")


def validate_finite(value: float, name: str) -> float:
    """Garante saída numérica finita."""
    if value is None or not math.isfinite(float(value)):
        raise NumericalError(f"Resultado inválido (não finito) em '{name}': {value!r}.")
    return float(value)
