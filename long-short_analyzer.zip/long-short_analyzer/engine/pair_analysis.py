"""Fase E: orquestração da análise de um par — contrato pair_stats.

Apenas métricas implementadas e validadas são expostas. Pendentes (Parte 2 do roteiro):
beta_rotation, coefficient_of_variation (cv_beta), historical_volatility.
"""
from __future__ import annotations

from typing import Any, Dict, Literal

from .cointegration import dickey_fuller
from .exceptions import InsufficientSampleError, NonMeanRevertingError
from .metrics import (
    beta_confidence_interval,
    coefficient_t_test,
    fisher_test,
    half_life,
    pearson_correlation,
    z_score,
)
from .regression import linear_regression
from .validation import ArrayLike, MIN_OBSERVATIONS, align_prices, require_min_samples

CONTRACT_KEYS = (
    "beta", "alpha", "residuals", "dickey_fuller", "cointegration_level",
    "z_score_current", "half_life", "fisher_min", "fisher_max",
    "ic_beta_min", "ic_beta_max", "t_beta", "t_alpha", "t_time", "std_residual",
)


def pair_stats(
    prices_a: ArrayLike,
    prices_b: ArrayLike,
    n_periods: int,
    *,
    with_time: bool = False,
    confidence_beta: float = 0.95,
    confidence_fisher: float = 0.99,
    missing: Literal["raise", "drop"] = "raise",
) -> Dict[str, Any]:
    """Análise do par (A dependente, B independente) nas últimas n_periods observações alinhadas.

    t_time é None se with_time=False; half_life é None se o resíduo não reverte à média.
    """
    require_min_samples(n_periods, MIN_OBSERVATIONS, "n_periods")
    df = align_prices(prices_a, prices_b, missing=missing)
    if len(df) < n_periods:
        raise InsufficientSampleError(f"Apenas {len(df)} observações alinhadas; n_periods={n_periods}.")
    window = df.iloc[-n_periods:]
    a, b = window["A"], window["B"]

    reg = linear_regression(a, b, with_time=with_time)
    resid = reg.residuals
    df_test = dickey_fuller(resid)
    k = reg.n_params - 1
    ic_min, ic_max = beta_confidence_interval(reg.beta, reg.se_beta, reg.n_obs, k, confidence_beta)
    f_min, f_max = fisher_test(pearson_correlation(a, b), n_periods, confidence_fisher)
    try:
        hl = half_life(resid)
    except NonMeanRevertingError:
        hl = None

    return {
        "beta": reg.beta,
        "alpha": reg.alpha,
        "residuals": resid,
        "dickey_fuller": df_test.tau,
        "cointegration_level": df_test.level,
        "z_score_current": z_score(resid),
        "half_life": hl,
        "fisher_min": f_min,
        "fisher_max": f_max,
        "ic_beta_min": ic_min,
        "ic_beta_max": ic_max,
        "t_beta": coefficient_t_test(reg.beta, reg.se_beta, reg.n_obs, k).t_stat,
        "t_alpha": coefficient_t_test(reg.alpha, reg.se_alpha, reg.n_obs, k).t_stat,
        "t_time": (
            coefficient_t_test(reg.time_coef, reg.se_time, reg.n_obs, k).t_stat if with_time else None
        ),
        "std_residual": float(resid.std(ddof=1)),
    }
