"""Protótipo de linha de comando do motor Long & Short por cointegração.

Uso:
  python prototype.py --csv precos.csv --a PETR4 --b PETR3 --n 250 --qtd-a 1000
  python prototype.py --demo            # dados SINTÉTICOS (não são dados de mercado)

O CSV deve ter a data na 1ª coluna e uma coluna de preço por ticker (cotação real).
Critério de entrada (manual): z > 2 => vende A e compra B; z < -2 => compra A e vende B,
com Q_B ≈ β·Q_A. Não é recomendação de investimento.
"""
from __future__ import annotations

import argparse
import math

import numpy as np
import pandas as pd

from engine import EngineError, pair_stats

Z_ENTRY = 2.0


def synthetic_demo(n: int = 300, seed: int = 42):
    rng = np.random.default_rng(seed)
    b = 40 + np.cumsum(rng.normal(0, 0.6, n))
    noise = np.zeros(n)
    for t in range(1, n):
        noise[t] = 0.85 * noise[t - 1] + rng.normal(0, 0.4)
    a = 5 + 0.8 * b + noise
    idx = pd.bdate_range("2024-01-02", periods=n)
    return pd.Series(a, idx, name="A_SINT"), pd.Series(b, idx, name="B_SINT")


def signal(z: float, beta: float, qtd_a: int) -> str:
    if abs(z) <= Z_ENTRY:
        return "SEM SINAL (|z| <= 2)"
    qtd_b = math.ceil(beta * qtd_a)
    if z > 0:
        return f"VENDER {qtd_a} de A e COMPRAR {qtd_b} de B"
    return f"COMPRAR {qtd_a} de A e VENDER {qtd_b} de B"


def report(a: pd.Series, b: pd.Series, n: int, qtd_a: int, with_time: bool, missing: str) -> None:
    s = pair_stats(a, b, n, with_time=with_time, missing=missing)
    hl = "indefinida (sem reversão)" if s["half_life"] is None else f"{s['half_life']:.2f} dias úteis"
    lvl = f"{s['cointegration_level']}%" if s["cointegration_level"] else "não cointegrado"
    print(f"Par: A={a.name} (dependente) x B={b.name} | janela N={n}")
    print(f"  alpha = {s['alpha']:.4f} | beta = {s['beta']:.4f} | IC(beta) = [{s['ic_beta_min']:.4f}; {s['ic_beta_max']:.4f}]")
    print(f"  t(beta) = {s['t_beta']:.2f} | t(alpha) = {s['t_alpha']:.2f}" + (f" | t(T) = {s['t_time']:.2f}" if with_time else ""))
    print(f"  Dickey-Fuller (tau) = {s['dickey_fuller']:.3f} -> {lvl}")
    print(f"  Fisher IC(rho) = [{s['fisher_min']:.2%}; {s['fisher_max']:.2%}]")
    print(f"  meia-vida = {hl} | desvio do resíduo = {s['std_residual']:.4f}")
    print(f"  z-score atual = {s['z_score_current']:.3f} -> {signal(s['z_score_current'], s['beta'], qtd_a)}")
    ok = s["cointegration_level"] == 99 and s["ic_beta_min"] > 0 and s["fisher_min"] > 0
    print("  Filtros do manual avaliados aqui (99%, IC beta > 0, Fisher min > 0):", "APROVADO" if ok else "REPROVADO")
    print("  (filtros multi-janela, CV(beta), meia-vida < 10, B×A: pendentes — Parte 3)")


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--csv"); p.add_argument("--a"); p.add_argument("--b")
    p.add_argument("--n", type=int, default=250); p.add_argument("--qtd-a", type=int, default=1000)
    p.add_argument("--with-time", action="store_true"); p.add_argument("--drop-missing", action="store_true")
    p.add_argument("--demo", action="store_true")
    args = p.parse_args()
    try:
        if args.demo or not args.csv:
            print("*** DADOS SINTÉTICOS (demonstração; não são cotações de mercado) ***")
            a, b = synthetic_demo()
            n = min(args.n, len(a))
        else:
            if not (args.a and args.b):
                p.error("--csv exige --a e --b")
            df = pd.read_csv(args.csv, index_col=0, parse_dates=True)
            a, b, n = df[args.a].rename(args.a), df[args.b].rename(args.b), args.n
        report(a, b, n, args.qtd_a, args.with_time, "drop" if args.drop_missing else "raise")
    except (EngineError, KeyError, FileNotFoundError) as exc:
        raise SystemExit(f"Erro: {exc}")


if __name__ == "__main__":
    main()
