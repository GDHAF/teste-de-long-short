"""Conjuntos de dados sintéticos determinísticos (seed fixa). NÃO são dados de mercado."""
import numpy as np
import pandas as pd
import pytest


def make_dates(n, start="2024-01-02"):
    return pd.bdate_range(start, periods=n)


def cointegrated_pair(n=250, alpha=2.0, beta=0.8, phi=0.5, sigma=0.5, seed=7):
    rng = np.random.default_rng(seed)
    x = 50 + np.cumsum(rng.normal(0, 1, n))
    noise = np.zeros(n)
    for t in range(1, n):
        noise[t] = phi * noise[t - 1] + rng.normal(0, sigma)
    y = alpha + beta * x + noise
    idx = make_dates(n)
    return pd.Series(y, index=idx, name="A"), pd.Series(x, index=idx, name="B")


def independent_random_walks(n=250, seed=11):
    rng = np.random.default_rng(seed)
    idx = make_dates(n)
    a = pd.Series(100 + np.cumsum(rng.normal(0, 1, n)), index=idx)
    b = pd.Series(100 + np.cumsum(rng.normal(0, 1, n)), index=idx)
    return a, b


@pytest.fixture
def coint():
    return cointegrated_pair()


@pytest.fixture
def walks():
    return independent_random_walks()
