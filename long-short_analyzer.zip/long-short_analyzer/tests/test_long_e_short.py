from long_e_short import LongEShort


def test_legacy_behavior_preserved():
    s = LongEShort()
    assert s.calcular(100, 48, 1, -2, 1) == {"A": -1, "B": 2}   # spread 4 > tol
    assert s.calcular(90, 48, 1, -2, 1) == {"A": 1, "B": -2}    # spread -6
    assert s.calcular(97, 48, 1, -2, 1) == {"A": 0, "B": 0}     # spread 1 <= tol
