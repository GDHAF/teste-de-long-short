import numpy as np
import pandas as pd
import pytest

from engine import InsufficientSampleError, InvalidSeriesError, MisalignedSeriesError, NumericalError
from engine.validation import align_prices, validate_finite, validate_prices
from conftest import make_dates


def test_empty_series():
    with pytest.raises(InvalidSeriesError):
        validate_prices([])


def test_non_numeric_series():
    with pytest.raises(InvalidSeriesError):
        validate_prices(["a", "b", "c"])


def test_infinite_values():
    with pytest.raises(InvalidSeriesError):
        validate_prices([1.0, np.inf, 3.0])


def test_non_positive_prices():
    with pytest.raises(InvalidSeriesError):
        validate_prices([1.0, 0.0, 3.0])
    with pytest.raises(InvalidSeriesError):
        validate_prices([1.0, -2.0, 3.0])


def test_duplicated_index():
    s = pd.Series([1.0, 2.0], index=pd.to_datetime(["2024-01-02", "2024-01-02"]))
    with pytest.raises(InvalidSeriesError):
        validate_prices(s)


def test_unsorted_index_is_sorted():
    s = pd.Series([2.0, 1.0], index=pd.to_datetime(["2024-01-03", "2024-01-02"]))
    assert validate_prices(s).index.is_monotonic_increasing


def test_missing_raise_and_drop():
    idx = make_dates(5)
    a = pd.Series([1, 2, np.nan, 4, 5.0], index=idx)
    b = pd.Series([1, 2, 3, 4, 5.0], index=idx)
    with pytest.raises(InvalidSeriesError):
        align_prices(a, b)
    out = align_prices(a, b, missing="drop")
    assert len(out) == 4 and not out.isna().any().any()


def test_misaligned_dates_use_intersection():
    a = pd.Series(np.arange(1, 101.0), index=make_dates(100))
    b = pd.Series(np.arange(1, 101.0), index=make_dates(100)[20:].append(pd.bdate_range("2030-01-01", periods=20)))
    out = align_prices(a, b)
    assert len(out) == 80 and out.index.equals(a.index[20:])


def test_no_common_dates():
    a = pd.Series([1.0, 2.0], index=pd.to_datetime(["2024-01-02", "2024-01-03"]))
    b = pd.Series([1.0, 2.0], index=pd.to_datetime(["2025-01-02", "2025-01-03"]))
    with pytest.raises(MisalignedSeriesError):
        align_prices(a, b)


def test_all_rows_missing_after_drop():
    idx = make_dates(2)
    a = pd.Series([np.nan, 1.0], index=idx)
    b = pd.Series([1.0, np.nan], index=idx)
    with pytest.raises(InsufficientSampleError):
        align_prices(a, b, missing="drop")


def test_validate_finite():
    assert validate_finite(1.5, "x") == 1.5
    for bad in (float("nan"), float("inf"), None):
        with pytest.raises(NumericalError):
            validate_finite(bad, "x")
