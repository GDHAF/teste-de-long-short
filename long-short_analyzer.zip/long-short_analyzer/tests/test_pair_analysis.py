import numpy as np
import pandas as pd
import pytest

from engine import (CONTRACT_KEYS, InsufficientSampleError, InvalidSeriesError, MisalignedSeriesError,
                    NonMeanRevertingError, pair_stats)
import engine.pair_analysis as pa
from conftest import cointegrated_pair


def test_contract_keys_exact(coint):
    out = pair_stats(*coint, 250)
    assert tuple(out) == CONTRACT_KEYS
    assert len(CONTRACT_KEYS) == 15


def test_values_for_cointegrated_pair(coint):
    out = pair_stats(*coint, 250)
    assert out["beta"] == pytest.approx(0.8, abs=0.05)
    assert out["cointegration_level"] == 99
    assert out["dickey_fuller"] < -4.32
    assert out["ic_beta_min"] < out["beta"] < out["ic_beta_max"]
    assert 0 < out["fisher_min"] < out["fisher_max"] < 1
    assert 0 < out["half_life"] < 10
    assert out["t_time"] is None
    assert isinstance(out["residuals"], pd.Series) and len(out["residuals"]) == 250
    assert out["std_residual"] == pytest.approx(out["residuals"].std(ddof=1))


def test_window_uses_last_n_periods(coint):
    y, x = coint
    out = pair_stats(y, x, 100)
    assert len(out["residuals"]) == 100
    assert out["residuals"].index[-1] == y.index[-1]


def test_with_time(coint):
    out = pair_stats(*coint, 250, with_time=True)
    assert out["t_time"] is not None and np.isfinite(out["t_time"])


def test_independent_walks_not_99(walks):
    assert pair_stats(*walks, 250)["cointegration_level"] < 99


def test_misaligned_dates_and_insufficient_overlap():
    y, x = cointegrated_pair(120)
    x2 = x.copy()
    x2.index = x2.index.shift(40, freq="B")  # só 80 datas em comum
    assert len(pair_stats(y, x2, 80)["residuals"]) == 80
    with pytest.raises(InsufficientSampleError):
        pair_stats(y, x2, 81)
    x3 = x.copy()
    x3.index = x3.index.shift(500, freq="B")
    with pytest.raises(MisalignedSeriesError):
        pair_stats(y, x3, 60)


def test_missing_observations(coint):
    y, x = coint
    y = y.copy()
    y.iloc[100] = np.nan
    with pytest.raises(InvalidSeriesError):
        pair_stats(y, x, 100)
    out = pair_stats(y, x, 100, missing="drop")
    assert len(out["residuals"]) == 100


def test_invalid_inputs(coint):
    y, x = coint
    with pytest.raises(InsufficientSampleError):
        pair_stats(y, x, 10)
    with pytest.raises(InvalidSeriesError):
        pair_stats(y * -1, x, 100)
    with pytest.raises(InsufficientSampleError):
        pair_stats(y.iloc[:50], x.iloc[:50], 100)


def test_half_life_none_when_not_mean_reverting(coint, monkeypatch):
    def boom(_):
        raise NonMeanRevertingError("x")
    monkeypatch.setattr(pa, "half_life", boom)
    out = pair_stats(*coint, 250)
    assert out["half_life"] is None and out["cointegration_level"] == 99


def test_price_scale_invariance(coint):
    y, x = coint
    a, b = pair_stats(y, x, 250), pair_stats(y * 1000, x * 1000, 250)
    assert b["beta"] == pytest.approx(a["beta"], rel=1e-9)
    assert b["dickey_fuller"] == pytest.approx(a["dickey_fuller"], rel=1e-7)
    assert b["z_score_current"] == pytest.approx(a["z_score_current"], rel=1e-7)


def test_deterministic(coint):
    a, b = pair_stats(*coint, 250), pair_stats(*coint, 250)
    assert a["dickey_fuller"] == b["dickey_fuller"] and a["beta"] == b["beta"]
