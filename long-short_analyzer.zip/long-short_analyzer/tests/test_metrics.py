import math

import numpy as np
import pytest
import statsmodels.api as sm
from scipy import stats

from engine import (InsufficientSampleError, NonMeanRevertingError, NumericalError, beta_confidence_interval,
                    coefficient_t_test, fisher_test, half_life, linear_regression, standardize, z_score)


def test_zscore_formula_and_ddof():
    e = np.random.default_rng(1).normal(size=100)
    assert z_score(e) == pytest.approx((e[-1] - e.mean()) / e.std(ddof=1), rel=1e-12)
    assert z_score(e, ddof=0) == pytest.approx((e[-1] - e.mean()) / e.std(ddof=0), rel=1e-12)
    assert standardize(e).iloc[-1] == pytest.approx(z_score(e), rel=1e-12)


def test_zscore_known_value():
    e = np.zeros(40)
    e[-1] = 1.0
    mean, std = 1 / 40, math.sqrt((39 * (1 / 40) ** 2 + (39 / 40) ** 2) / 39)
    assert z_score(e) == pytest.approx((1 - mean) / std, rel=1e-12)


def test_zscore_scale_and_shift_invariance():
    e = np.random.default_rng(2).normal(size=80)
    assert z_score(1e6 * e + 5e5) == pytest.approx(z_score(e), rel=1e-9)


def test_zscore_edge_cases():
    with pytest.raises(NumericalError):
        z_score(np.ones(50))
    with pytest.raises(InsufficientSampleError):
        z_score(np.arange(5.0))


def test_half_life_exact_deterministic():
    e = 10 * 0.9 ** np.arange(60)  # Δe = -0,1 e_{t-1} exatamente => θ=0,1
    assert half_life(e) == pytest.approx(math.log(2) / 0.1, rel=1e-9)


def test_half_life_ar1_statistical():
    rng = np.random.default_rng(0)
    e = np.zeros(5000)
    for t in range(1, 5000):
        e[t] = 0.9 * e[t - 1] + rng.normal()
    assert half_life(e) == pytest.approx(math.log(2) / 0.1, rel=0.2)


@pytest.mark.parametrize("series", [1.05 ** np.arange(60), np.arange(1.0, 61.0)])
def test_half_life_rejects_non_mean_reverting(series):
    with pytest.raises(NonMeanRevertingError):
        half_life(series)


def test_half_life_insufficient():
    with pytest.raises(InsufficientSampleError):
        half_life(np.arange(5.0))


def test_fisher_manual_example():
    """Manual: F(ρ)=0,2609; n=120; 99% (z=2,575) => ρ ∈ [2,28%; 46,13%] (valores arredondados no manual)."""
    lo, hi = fisher_test(math.tanh(0.2609), 120, z_critical=2.575)
    assert lo == pytest.approx(0.0228, abs=5e-5) and hi == pytest.approx(0.4613, abs=5e-5)


def test_fisher_default_z_and_errors():
    lo, hi = fisher_test(0.5, 100, 0.95)
    z = stats.norm.ppf(0.975)
    assert lo == pytest.approx(math.tanh(math.atanh(0.5) - z / math.sqrt(97)), rel=1e-12)
    assert lo < 0.5 < hi
    for bad in (1.0, -1.0, float("nan")):
        with pytest.raises(NumericalError):
            fisher_test(bad, 100)
    with pytest.raises(NumericalError):
        fisher_test(0.5, 3)


def test_t_critical_values_manual_60gl():
    """Manual: 60 gl — 99% unilateral = 2,39; 95% bilateral = 2,00."""
    assert stats.t.ppf(0.99, 60) == pytest.approx(2.39, abs=5e-3)
    lo, hi = beta_confidence_interval(0.0, 1.0, n=62, k=1, conf=0.95)
    assert hi == pytest.approx(2.00, abs=5e-3) and lo == pytest.approx(-hi)


def test_ic_and_t_match_statsmodels(coint):
    y, x = coint
    r = linear_regression(y, x)
    ref = sm.OLS(y.to_numpy(), sm.add_constant(x.to_numpy())).fit()
    lo, hi = beta_confidence_interval(r.beta, r.se_beta, r.n_obs, 1, 0.95)
    np.testing.assert_allclose([lo, hi], ref.conf_int(0.05)[1], rtol=1e-9)
    t = coefficient_t_test(r.beta, r.se_beta, r.n_obs, 1)
    assert t.t_stat == pytest.approx(ref.tvalues[1], rel=1e-9)
    assert t.p_value == pytest.approx(ref.pvalues[1], rel=1e-6)
    assert coefficient_t_test(r.beta, r.se_beta, r.n_obs, 1, tail="right").p_value == pytest.approx(t.p_value / 2, rel=1e-9)


def test_t_test_errors():
    with pytest.raises(NumericalError):
        coefficient_t_test(1.0, 0.0, 50, 1)
    with pytest.raises(NumericalError):
        coefficient_t_test(1.0, 1.0, 2, 1)
    with pytest.raises(ValueError):
        coefficient_t_test(1.0, 1.0, 50, 1, tail="x")
