import numpy as np
import pytest
from statsmodels.tsa.stattools import adfuller

from engine import (InsufficientSampleError, NumericalError, classify_cointegration_level,
                    dickey_fuller, linear_regression)
from engine.cointegration import MANUAL_CRITICAL_VALUES


def test_manual_critical_values():
    assert MANUAL_CRITICAL_VALUES == {99: -4.32, 95: -3.67, 90: -3.28}


def test_manual_numeric_example():
    """Manual: γ=-0,190; EP=0,048 => τ=-3,958 => 95%."""
    tau = -0.190 / 0.048
    assert tau == pytest.approx(-3.958, abs=5e-4)
    assert classify_cointegration_level(tau) == 95


@pytest.mark.parametrize("tau,level", [(-4.50, 99), (-4.33, 99), (-4.32, 95), (-3.958, 95), (-3.67, 90),
                                       (-3.50, 90), (-3.28, 0), (-2.0, 0), (1.0, 0)])
def test_classification_levels(tau, level):
    assert classify_cointegration_level(tau) == level


def test_classification_rejects_nan():
    with pytest.raises(NumericalError):
        classify_cointegration_level(float("nan"))


def test_tau_matches_manual_formula_and_adfuller(coint):
    y, x = coint
    e = linear_regression(y, x).residuals.to_numpy()
    res = dickey_fuller(e)
    # fórmula do manual: EP(γ) = sqrt(Σu²/(n-2)) / sqrt(Σ(e_{t-1}-ē)²)
    d, lag = np.diff(e), e[:-1]
    g = np.polyfit(lag, d, 1)
    u = d - np.polyval(g, lag)
    se = np.sqrt((u @ u) / (len(d) - 2)) / np.sqrt(((lag - lag.mean()) ** 2).sum())
    assert res.gamma == pytest.approx(g[0], rel=1e-9)
    assert res.tau == pytest.approx(g[0] / se, rel=1e-9)
    # statsmodels (maxlag=0, constante) usa a mesma regressão auxiliar
    assert res.tau == pytest.approx(adfuller(e, maxlag=0, regression="c", autolag=None, result_object=False)[0], rel=1e-9)
    assert res.n_obs == len(e) - 1


def test_cointegrated_pair_detected(coint):
    y, x = coint
    res = dickey_fuller(linear_regression(y, x).residuals)
    assert res.tau < -4.32 and res.level == 99


def test_independent_walks_not_cointegrated_at_99(walks):
    a, b = walks
    res = dickey_fuller(linear_regression(a, b).residuals)
    # com semente fixa; falsos positivos a 90% ocorrem por construção do teste
    assert res.level < 99


def test_insufficient_and_invalid():
    with pytest.raises(InsufficientSampleError):
        dickey_fuller(np.random.default_rng(0).normal(size=10))
    with pytest.raises(NumericalError):  # série perfeitamente determinística: EP(γ)=0
        dickey_fuller(10 * 0.9 ** np.arange(60))
