import numpy as np
import pandas as pd
import pytest
import statsmodels.api as sm

from engine import (InsufficientSampleError, MisalignedSeriesError, SingularRegressionError,
                    compute_residuals, linear_regression)
from conftest import cointegrated_pair, make_dates


def test_textbook_example_exact():
    r = linear_regression([2, 4, 5, 4, 5], [1, 2, 3, 4, 5])
    assert r.alpha == pytest.approx(2.2, rel=1e-12)
    assert r.beta == pytest.approx(0.6, rel=1e-12)
    assert r.se_beta == pytest.approx(np.sqrt(0.08), rel=1e-12)
    assert r.se_alpha == pytest.approx(np.sqrt(0.88), rel=1e-12)
    assert r.sigma2 == pytest.approx(0.8, rel=1e-12)
    np.testing.assert_allclose(r.residuals.to_numpy(), [-0.8, 0.6, 1.0, -0.6, -0.2], atol=1e-12)
    assert r.time_coef is None and r.se_time is None


def test_matches_statsmodels_simple(coint):
    y, x = coint
    r = linear_regression(y, x)
    ref = sm.OLS(y.to_numpy(), sm.add_constant(x.to_numpy())).fit()
    np.testing.assert_allclose([r.alpha, r.beta], ref.params, rtol=1e-9)
    np.testing.assert_allclose([r.se_alpha, r.se_beta], ref.bse, rtol=1e-9)
    np.testing.assert_allclose(r.covariance, ref.cov_params(), rtol=1e-9)
    np.testing.assert_allclose(r.residuals.to_numpy(), ref.resid, atol=1e-9)
    np.testing.assert_allclose((r.fitted + r.residuals).to_numpy(), y.to_numpy(), rtol=1e-12)
    assert r.df_resid == 248


def test_with_time_matches_statsmodels():
    rng = np.random.default_rng(3)
    n = 120
    x = 30 + np.cumsum(rng.normal(size=n))
    t = np.arange(1, n + 1)
    y = 1 + 2 * x + 0.05 * t + rng.normal(0, 0.5, n)
    r = linear_regression(y, x, with_time=True)
    ref = sm.OLS(y, np.column_stack([np.ones(n), x, t])).fit()
    np.testing.assert_allclose([r.alpha, r.beta, r.time_coef], ref.params, rtol=1e-9)
    np.testing.assert_allclose([r.se_alpha, r.se_beta, r.se_time], ref.bse, rtol=1e-9)
    assert r.df_resid == n - 3 and r.n_params == 3


def test_with_time_exact_recovery():
    rng = np.random.default_rng(5)
    n = 60
    x = 10 + np.cumsum(rng.normal(size=n))
    y = 1 + 2 * x + 0.5 * np.arange(1, n + 1)
    r = linear_regression(y, x, with_time=True)
    assert (r.alpha, r.beta, r.time_coef) == pytest.approx((1, 2, 0.5), rel=1e-9)
    assert np.abs(r.residuals.to_numpy()).max() < 1e-8


def test_compute_residuals_consistent_with_regression(coint):
    y, x = coint
    r = linear_regression(y, x)
    np.testing.assert_allclose(compute_residuals(y, x, r.alpha, r.beta).to_numpy(), r.residuals.to_numpy(), atol=1e-10)
    rt = linear_regression(y, x, with_time=True)
    np.testing.assert_allclose(
        compute_residuals(y, x, rt.alpha, rt.beta, rt.time_coef).to_numpy(), rt.residuals.to_numpy(), atol=1e-10)


def test_convention_a_dependent():
    """A = alpha + beta*B: trocar os papéis NÃO dá o mesmo beta (convenção do manual)."""
    y, x = cointegrated_pair()
    assert linear_regression(y, x).beta != pytest.approx(linear_regression(x, y).beta, rel=1e-3)


def test_numpy_inputs_work():
    r = linear_regression(np.array([2, 4, 5, 4, 5.0]), np.array([1, 2, 3, 4, 5.0]))
    assert isinstance(r.residuals, pd.Series)


def test_invalid_inputs():
    with pytest.raises(MisalignedSeriesError):
        linear_regression([1, 2, 3, 4], [1, 2, 3])
    with pytest.raises(SingularRegressionError):
        linear_regression([1, 2, 3, 4, 5], [2, 2, 2, 2, 2])
    with pytest.raises(InsufficientSampleError):
        linear_regression([1, 2], [1, 2])
    with pytest.raises(InsufficientSampleError):
        linear_regression([1, 2, 3], [1, 2, 4], with_time=True)


def test_different_indexes_rejected():
    a = pd.Series(np.arange(5.0), index=make_dates(5))
    b = pd.Series(np.arange(5.0) ** 2, index=make_dates(5, "2025-01-02"))
    with pytest.raises(MisalignedSeriesError):
        linear_regression(a, b)


def test_time_collinear_with_x():
    n = 30
    t = np.arange(1, n + 1, dtype=float)
    with pytest.raises(SingularRegressionError):
        linear_regression(2 * t + 1, t, with_time=True)
